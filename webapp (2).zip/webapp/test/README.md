# Py_WebSurveillance
Python live browser surveillance with motion detection
