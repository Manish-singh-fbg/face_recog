
import mysql.connector
import os
from datetime import datetime
from datetime import timedelta
import time

class Database:

    def list_employees(self,sql_query,input):
        try:
            connection = mysql.connector.connect(host='localhost',
                                                 database='face_recognition',
                                                 user='root',
                                                 password='root',
                                                 charset='utf8')
            cursor = connection.cursor(prepared=True)

            cursor.execute(sql_query, input)
            result = cursor.fetchall()
            return result
        except mysql.connector.Error as error :
            print(error)
            connection.rollback()
        finally:
            # closing database connection.
            if (connection.is_connected()):
                cursor.close()
                connection.close()
                print("MySQL connection is closed")


def hello_world():
    # db = Database()
    # now = datetime.now()-timedelta(seconds=100)
    # start_date = now.strftime('%Y-%m-%d %H:%M:%S')
    # end = datetime.now()-timedelta(seconds=100)
    # end_date = end.strftime('%Y-%m-%d %H:%M:%S')
    # reports_query = "SELECT img_path, serverroom, predicted_user,flag FROM report where  WHERE time>=%s and time<=%e"
    # input = (start_date, end_date,)
    # emps = db.list_employees(reports_query, input)
    # print(emps)
    db = Database()
    # now = datetime.now() - timedelta(seconds=100)
    # start_date = now.strftime('%Y-%m-%d %H:%M:%S')
    # end = datetime.now()-timedelta(seconds=100)
    # end_date = end.strftime('%Y-%m-%d %H:%M:%S')
    # reports_query = "SELECT img_path, serverroom, predicted_user,flag FROM report  WHERE `created_at` >=%s and `created_at`<=%s"
    # input = (start_date, end_date,)
    # print(input)
    # emps = db.list_employees(reports_query, input)
    #print(emps)
    # reports_query1 = "SELECT correctness FROM report where correctness='yes' or  correctness='no'"
    # input1 = ''
    # crs = db.list_employees(reports_query1, input1)
    # y=0
    # n=0
    # print(len(crs))
    # for cr in crs:
        # if cr[0] == 'yes':
            # y+=1
        # else:
            # n+=1

    # print('yes',y)
    # print('no', n)
    # print('percentage',y/len(crs) *100 )
	#past = time.time() - 1000*30*60
    # past = time.time() - 1000*30*60
#     # full_file_path ='C:\Users\manish_singh1\Desktop\webapp\static\Serverroom\Serverroom2\5.jpg'
#     # print( os.path.getmtime(full_file_path))
    past = time.time()-60*60
    print(past)
    full_file_path ='C:\\Users\\manish_singh1\\Desktop\\webapp\\static\\Serverroom\\Serverroom2\\5.jpg'
    print(past,time.time(),full_file_path)
    print(os.path.getctime(full_file_path))
    local_time = time.ctime(time.time())
    local_time1 = time.ctime(past)
    local_time2 = time.ctime(os.path.getmtime(full_file_path))

    print("Local time:", local_time)

    print(local_time1)
    print(local_time2)
hello_world()