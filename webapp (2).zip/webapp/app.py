from flask import Flask, flash, redirect, render_template, request, session, abort,Markup,json,jsonify
import mysql.connector
import dataset_maker as dm
from datetime import datetime
from datetime import timedelta
import math
from sklearn import neighbors
import os
import os.path
import pickle
from PIL import Image, ImageDraw
import face_recognition
from face_recognition.face_recognition_cli import image_files_in_folder
import time

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
app = Flask(__name__)
past = time.time() - 3600*2


def predict(X_img_path, knn_clf=None, model_path=None, distance_threshold=0.5):
    print(time.time())
    print(past)
    if not os.path.isfile(X_img_path) or os.path.splitext(X_img_path)[1][1:] not in ALLOWED_EXTENSIONS:
        raise Exception("Invalid image path: {}".format(X_img_path))

    if knn_clf is None and model_path is None:
        raise Exception("Must supply knn classifier either thourgh knn_clf or model_path")

    # Load a trained KNN model (if one was passed in)
    if knn_clf is None:
        with open(model_path, 'rb') as f:
            knn_clf = pickle.load(f)

    # Load image file and find face locations
    X_img = face_recognition.load_image_file(X_img_path)
    X_face_locations = face_recognition.face_locations(X_img)

    # If no faces are found in the image, return an empty result.
    if len(X_face_locations) == 0:
        return []

    # Find encodings for faces in the test iamge
    faces_encodings = face_recognition.face_encodings(X_img, known_face_locations=X_face_locations)
    print('faces_encodings',faces_encodings)
    # Use the KNN model to find the best matches for the test face
    closest_distances = knn_clf.kneighbors(faces_encodings, n_neighbors=3)
    are_matches = [closest_distances[0][i][0] <= distance_threshold for i in range(len(X_face_locations))]
    print(are_matches)
    # Predict classes and remove classifications that aren't within the threshold
    return [(pred, loc) if rec else ("unknown", loc) for pred, loc, rec in zip(knn_clf.predict(faces_encodings), X_face_locations, are_matches)]


class Database:

    def list_employees(self,sql_query,input,type):
        try:
            connection = mysql.connector.connect(host='localhost',
                                                 database='face_recognition',
                                                 user='root',
                                                 password='root',
                                                 charset='utf8')
            cursor = connection.cursor(prepared=True)


            if type=='fetchone':
                cursor.execute(sql_query, input)
                result = cursor.fetchone()
            elif type=='fetchall':
                print('fetchall')
                cursor.execute(sql_query, input)
                result = cursor.fetchall()
            elif type=='commit':
                result = cursor.executemany(sql_query, input)
                connection.commit()
                print(cursor.rowcount, "Record inserted successfully into python_users table")
            elif type=='save':
                print('save')
                result = cursor.execute(sql_query, input)
                connection.commit()
                print(cursor.rowcount, "Record inserted successfully into python_users table")
            elif type=='update':
                result = cursor.execute(sql_query, input)
                connection.commit()
            return result
        except mysql.connector.Error as error :
            print(error)
            connection.rollback()
        finally:
            # closing database connection.
            if (connection.is_connected()):
                cursor.close()
                connection.close()
                print("MySQL connection is closed")




@app.route('/user')
def user():
    if session.get('logged_in'):
        return render_template('user.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"




@app.route('/Admin')
def Admin():
    if session.get('logged_in'):
        return render_template('Admin.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"

@app.route('/Generate', methods=['POST'])
def Generate():
    now = datetime.now()-timedelta(days=3)
    start_date = now.strftime('%Y-%m-%d %H:%M:%S')
    sql_insert_query = """ INSERT INTO `report`
                                  (`img_path`, `serverroom`, `predicted_user`,`flag`) VALUES (%s,%s,%s,%s)"""
    db = Database()
    na = str(request.form['sr'])
    end = datetime.now() + timedelta(seconds=1500)
    end_date = end.strftime('%Y-%m-%d %H:%M:%S')
    #reports_query = "SELECT img_path, serverroom, predicted_user,flag,id,correctness FROM report WHERE created_at>=%s and created_at<=%s"
    #input = (start_date, end_date,)
    if na=='all':
        reports_query = "SELECT img_path, serverroom, predicted_user,flag,id,correctness FROM report"
        input =''
        emps = db.list_employees(reports_query, input, 'fetchall')
        reports_query1 = "SELECT correctness FROM report where correctness='yes' or  correctness='no'"
        input1 = ''
        crs = db.list_employees(reports_query1, input1, 'fetchall')
    else:
        reports_query = "SELECT img_path, serverroom, predicted_user,flag,id,correctness FROM report WHERE serverroom=%s"
        input = (na,)
        emps = db.list_employees(reports_query, input, 'fetchall')
        reports_query1 = "SELECT correctness FROM report where (correctness='yes' or  correctness='no') and  serverroom=%s "
        input1 = (na,)
        crs = db.list_employees(reports_query1, input1, 'fetchall')

    y = 0
    n = 0
    print(len(crs))
    for cr in crs:
        if cr[0] == 'yes':
            y += 1
        else:
            n += 1

    if len(crs) == 0:
        per = 0
    else:
        per = y / len(crs) * 100
    print('percentage',per)
    reports_query = "SELECT name, iduser FROM user"
    input1 = ''
    usr = db.list_employees(reports_query, input1, 'fetchall')
    reports_query1 = "SELECT name FROM server_room"
    serverlist = db.list_employees(reports_query1, input1, 'fetchall')
    #hists = ['Serverrrom/' + name + '/' + file for file in hists]
    return render_template('supervisor.html', result=emps, users=usr,per=per, serverlists=serverlist,content_type='application/json')

@app.route('/')
def home():
    if not session.get('logged_in'):
        return render_template('login.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"




@app.route('/login', methods=['POST'])
def do_admin_login():
    POST_USERNAME = str(request.form['username'])
    POST_PASSWORD = str(request.form['password'])
    db = Database()
    sql_query = "SELECT Name,Role FROM user where email=%s and name=%s"
    input = (POST_USERNAME, POST_PASSWORD,)
    emps = db.list_employees(sql_query, input,'fetchone')
    print(emps)
    if emps:
        session['logged_in'] = True
        session['name']= emps[0]
        if emps[1] == 1:
            return render_template('Admin.html')
        elif emps[1] == 2:
            db = Database()
            input1 = ''
            reports_query1 = "SELECT name FROM server_room"
            serverlist = db.list_employees(reports_query1, input1, 'fetchall')
            return render_template('supervisor.html', serverlists=serverlist)
        else:
            return render_template('user.html')
    else:
        flash('wrong password!')
        return home()

@app.route("/logout")
def logout():
	session['logged_in'] = False
	return home()

@app.route("/dashboard")
def dashboard():
    if session.get('logged_in'):
        return render_template('dashboard.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"

@app.route('/selectuser')
def selectuser():
    db = Database()
    reports_query = "SELECT name, iduser FROM user"
    input = ''
    usr = db.list_employees(reports_query, input, 'fetchall')
    print(usr)
    return json.dumps(usr)
    # hists = ['Serverrrom/' + name + '/' + file for file in hists]
   # return render_template('dashboard.html', result=usr, content_type='application/json')

@app.route('/verify', methods=['Post'])
def verify():
    id = str(request.form['id'])
    real = str(request.form['user'])
    correctness = str(request.form['correctness'])
    db = Database()
    print('11111')
    sql_update_query = """Update report set correctness = %s, user=%s where id = %s"""
    input = (correctness, real,id,)
    emps = db.list_employees(sql_update_query, input, 'update')
    return "nothing"

    # hists = ['Serverrrom/' + name + '/' + file for file in hists]
    #return render_template('dashboard.html')





##############updated
@app.route('/createuser', methods=['Post'])
def createuser():
    if session.get('logged_in'):
        name = str(request.form['uname'])
        email = str(request.form['email'])
        role = str(request.form['role'])
        db = Database()
        sql_insert_query = """ INSERT INTO `user`
                                        (`name`, `email`, `role`) VALUES (%s,%s,%s)"""
        input = (name, email, role,)
        result = db.list_employees(sql_insert_query, input, 'save')
        message = Markup(
            "<script>document.getElementById('London').style.display = 'block';</script> <h2 style='color:green'>Successfully created user</h2>")
        flash(message)
        return render_template('user.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/Supervisorslist', methods=['Get'])
def Supervisorslist():
    if session.get('logged_in'):

        db = Database()
        reports_query1 = "SELECT name,email,Role FROM user where role = '2'"
        input1 = ''
        crs = db.list_employees(reports_query1, input1, 'fetchall')
        message = Markup(
            "<script>document.getElementById('Paris').style.display = 'block';</script>")
        flash(message)
        return render_template('user.html' , result=crs)
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/employeelist', methods=['Get'])
def employeelist():
    if session.get('logged_in'):

        db = Database()
        reports_query1 = "SELECT name,email,Role FROM user where role = '3'"
        input1 = ''
        crs = db.list_employees(reports_query1, input1, 'fetchall')
        message = Markup(
            "<script>document.getElementById('Tokyo').style.display = 'block';</script>")
        flash(message)
        return render_template('user.html' , resultemp=crs)
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/alluserlist', methods=['Get'])
def alluserlist():
    if session.get('logged_in'):

        db = Database()
        reports_query1 = "SELECT name,email,Role FROM user"
        input1 = ''
        crs = db.list_employees(reports_query1, input1, 'fetchall')
        message = Markup(
            "<script>document.getElementById('All').style.display = 'block';</script>")
        flash(message)
        return render_template('user.html' , resultall=crs)
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/getalluserlist', methods=['Get'])
def getalluserlist():
    if session.get('logged_in'):

        db = Database()
        reports_query1 = "SELECT name,email,Role FROM user role = '3'"
        input1 = ''
        crs = db.list_employees(reports_query1, input1, 'fetchall')

        return render_template('user.html' , resultall=crs)
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"



@app.route('/createdata')
def createdata():
    if session.get('logged_in'):
        db = Database()
        reports_query1 = "SELECT name,iduser FROM user"
        input1 = ''
        userlist = db.list_employees(reports_query1, input1, 'fetchall')
        return render_template('createdata.html', resultall=userlist)
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/createdataset', methods=['POST'])
def createdataset():
    db = Database()
    reports_query1 = "SELECT name,iduser FROM user"
    input1 = ''
    userlist = db.list_employees(reports_query1, input1, 'fetchall')
    name = str(request.form['user'])
    res = dm.datasetCreator(name)
    if res == 'done':
        #for x in multiselect:
        hists = os.listdir('static/Dataset/train/'+name)
        print(hists)
        hists = ['Dataset/train/'+name+'/'+ file for file in hists]
        message = Markup(
            "Dataset Created successfully ")
        flash(message)
        return render_template('createdata.html', hists=hists,resultall=userlist)
        #return render_template('user.html' , result = res )
    else:
        hists = os.listdir('static/error')
        hists = ['error/' + file for file in hists]
        return render_template('createdata.html', hists=hists)



@app.route('/traindata')
def traindata():
    if session.get('logged_in'):
        return render_template('traindata.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/traindataset', methods=['GET'])
def traindataset():
    if session.get('logged_in'):
        classifire = dm.train("static/Dataset/train", model_save_path="trained_knn_model.clf", n_neighbors=3)
        if classifire:
            message = Markup(
                "<script>$('#done').show();$('#content1').show();</script> Successfully Created dataset.")
            flash(message)
            return render_template('traindata.html')

    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/servermapping')
def servermapping():
    if session.get('logged_in'):
        db = Database()
        reports_query1 = "SELECT name,iduser FROM user"
        input1 = ''
        userlist = db.list_employees(reports_query1, input1, 'fetchall')
        db = Database()
        reports_query1 = "SELECT name FROM server_room"
        serverlist = db.list_employees(reports_query1, input1, 'fetchall')
        return render_template('servermapping.html', userlists=userlist,serverlists=serverlist )
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"

@app.route('/mapuserserver',methods=['Post'])
def mapuserserver():
    if session.get('logged_in'):
        sql_insert_query = """ INSERT INTO `employee`
                                      ( `access`,`name`) VALUES (%s,%s)"""
        userlist = request.form.getlist('users')
        sr = str(request.form['sr'])
        # for x in multiselect:
        db = Database()
        input = [(sr, x,) for x in userlist]
        emps = db.list_employees(sql_insert_query, input, 'commit')
        message = Markup(
            "<h2>Successfully Mapped user to server room.</h2>")
        flash(message)
        db = Database()
        reports_query1 = "SELECT name,iduser FROM user"
        input1 = ''
        userlist = db.list_employees(reports_query1, input1, 'fetchall')
        db = Database()
        reports_query1 = "SELECT name FROM server_room"
        serverlist = db.list_employees(reports_query1, input1, 'fetchall')
        return render_template('servermapping.html', userlists=userlist, serverlists=serverlist)
        #return render_template('servermapping.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"

@app.route('/setting')
def setting():
    if session.get('logged_in'):
        return render_template('setting.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"

@app.route('/serverroom', methods=['Post'])
def serverroom():
    if session.get('logged_in'):
        name = str(request.form['uname'])
        db = Database()
        sql_insert_query = """ INSERT INTO `server_room`
                                                (`name`) VALUES (%s)"""
        input = (name,)
        result1 = db.list_employees(sql_insert_query, input, 'save')
        sql = "select name from server_room"
        input1 = ''
        results = db.list_employees(sql, input, 'fetchall')
        dl_path = "static/Serverroom/" + name;
        if not os.path.exists(dl_path):
            os.makedirs(dl_path)
        message = Markup(
            "<script>document.getElementById('Paris').style.display = 'block';</script> <h2 style='color:green'>Successfully Created Server Room</h2>")
        flash(message)
        return render_template('setting.html',result=results)

    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/checkuser')
def checkuser():
    if session.get('logged_in'):
        # db = Database()
        # reports_query1 = "SELECT name,iduser FROM user"
        # input1 = ''
        # userlist = db.list_employees(reports_query1, input1, 'fetchall')
        # reports_query1 = "SELECT name FROM server_room"
        # serverlist = db.list_employees(reports_query1, input1, 'fetchall')
        return render_template('checkuser.html' )
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"

@app.route('/verifyuser',methods=['Post'])
def verifyuser():
    if session.get('logged_in'):
        sql_insert_query = """ INSERT INTO `report`
                                          (`img_path`, `serverroom`, `predicted_user`,`flag`) VALUES (%s,%s,%s,%s)"""
        db = Database()
        reports_query1 = "SELECT name FROM server_room"
        input1 = ''
        serverlist = db.list_employees(reports_query1, input1, 'fetchall')
        X = []
        # hists = os.listdir('static/Serverroom/' + na)
        for nam in serverlist:
            na = nam[0]
            for image_file in os.listdir('static/Serverroom/' + na):
                full_file_path = os.path.join('static/Serverroom/' + na, image_file)
                if os.path.getmtime(full_file_path) >= past:
                    print('full_file_path',full_file_path)
                    # Find all people in the image using a trained classifier model
                    # Note: You can pass in either a classifier file name or a classifier model instance
                    predictions = predict(full_file_path, model_path="trained_knn_model.clf")
                    print('predictions',predictions,past)

                    # Print results on the console
                    for name, (top, right, bottom, left) in predictions:
                        path_img = 'Serverroom/' + na + '/' + image_file
                        if name == 'unknown':
                            print('uncknown')
                            name='unknown'
                            flag = 'red'
                            input = (path_img, na, name, flag,)
                            emps = db.list_employees(sql_insert_query, input, 'save')
                        else:
                            sql_query1 = "SELECT name FROM user where iduser=%s"
                            input2 = (name,)
                            usrname = db.list_employees(sql_query1, input2, 'fetchone')
                            print('username',usrname[0])
                            sql_query = "SELECT id FROM employee where Name=%s and access=%s"
                            input = (name, na,)
                            emps = db.list_employees(sql_query, input, 'fetchone')
                            if emps:
                                print('emp1',emps)
                                flag = 'green'
                                input = (path_img, na, usrname[0], flag,)
                                emps = db.list_employees(sql_insert_query, input, 'save')
                            else:
                                flag = 'red'
                                print('emp2')
                                input = (path_img, na, usrname[0], flag,)
                                emps = db.list_employees(sql_insert_query, input, 'save')
                        print("- Found {} at ({}, {})".format(name, left, top))

        message = Markup(
            "<script>$('#done').show();$('#content1').show();</script> Successfully Verified server data.")
        flash(message)
        return render_template('checkuser.html')
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


@app.route('/supervisor')
def supervisor():
    if session.get('logged_in'):
        db = Database()
        input1 = ''
        reports_query1 = "SELECT name FROM server_room"
        serverlist = db.list_employees(reports_query1, input1, 'fetchall')
        return render_template('supervisor.html', serverlists=serverlist)
    else:
        return "Hello Boss! <a href='/logout'>Logout</a>"


if __name__ == "__main__":
    app.secret_key = os.urandom(12)
    app.run(debug=True)
#app.run(debug=True, host='0.0.0.0', port=4000)